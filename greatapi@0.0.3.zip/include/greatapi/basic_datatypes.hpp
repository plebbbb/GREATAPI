//Put all your header file includes in here plz.
#include "greatapi/angle_units/angle_autoconvert.hpp"
#include "greatapi/angle_units/srad.hpp"
#include "greatapi/coordinate/coord.hpp"
#include "greatapi/coordinate/position.hpp"
