//Put all your header file includes in here plz.
#pragma once

#ifndef WAYPOINTS_HPP
#define WAYPOINTS_HPP

#include "greatapi/units/waypoint_generator/universal_generator.hpp"
#include "greatapi/units/waypoint_generator/bezier.hpp"
#include "greatapi/units/waypoint_generator/linear.hpp"


#endif
