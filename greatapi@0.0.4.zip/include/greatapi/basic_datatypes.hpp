//Put all your header file includes in here plz.

#pragma once

#ifndef BASIC_DATATYPE_HPP
#define BASIC_DATATYPE_HPP

#include "greatapi/angle_units/angle_autoconvert.hpp"
#include "greatapi/angle_units/srad.hpp"
#include "greatapi/coordinate/coord.hpp"
#include "greatapi/coordinate/position.hpp"

#endif
